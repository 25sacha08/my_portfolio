<template>
  <div>
    <Header />
    <transition mode="out-in">
      <router-view />
    </transition>
    <Footer />
  </div>
</template>
<script setup>
import Header from './components/Header.vue'
import Footer from './components/Footer.vue'
</script>
